package com.fly.pro2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ApiController {

	@Autowired
	ApiDAO dao; 
	
	/*
	 * @RequestMapping("open.do") public ModelAndView apiMain(HttpServletRequest
	 * req, HttpServletResponse res) throws Exception { HashMap<String, Object>
	 * dataMap = new HashMap<String, Object>(); HashMap<String, String> hMap = new
	 * HashMap<String, String>(); hMap.put("fUy8d2QG3M1kLEwTgnyNa45QSjJQEQb6",
	 * "authkey"); hMap.put("20210928", "searchdate"); hMap.put("AP01", "data");
	 * 
	 * dataMap.put("ajaxcallReturn", 서비스.메소드명(hMap)); return dataMap; }
	 */

@RequestMapping("itemInsert.do")
	// 입력선택 값과 검색하려는 날짜
public String create(String category, String searchdate, Model model) {
	// 데이터 받아오는 JSON 객체 생성
	ApiJSON2 itemList = new ApiJSON2();
	// 전달값을 받은 JSON의 DATA를 DTO에 저장 
	ApiDTO accessData = itemList.getApiItems(searchdate, category);
	// 실행 DAO(mybatis 및 JDBC)
	ApiDAO dao = new ApiDAO();
	dao.create(accessData);
	// 리턴
	return "apiS";
}
	
	
	
	
}