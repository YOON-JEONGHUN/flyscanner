package com.fly.pro2;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


	@Repository
	public class ApiDAO {

	    @Autowired
	    SqlSessionTemplate mybatis;
	
	    public void create(ApiDTO apiDTO) {
			System.out.println(apiDTO);
			int result = mybatis.insert("apiMapper.create", apiDTO);
			System.out.println(result);
	    }  
	    
}
